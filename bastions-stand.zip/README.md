# Bastion's Stand — Co-op Tower Defense

A multiplayer tower defense game for 1-4 players. Each player defends their own zone of the map, builds towers, and works together to survive 20 waves of enemies.

---

## HOW TO GET THIS ONLINE (Step by Step)

You need two things: a GitHub account (free) and a Render account (free). Here's exactly what to do:

### Step 1: Create a GitHub account (skip if you have one)

1. Go to **https://github.com** and click **Sign Up**
2. Follow the steps to create a free account
3. Verify your email

### Step 2: Upload the game code to GitHub

1. Log into GitHub
2. Click the **+** button in the top-right corner → **New repository**
3. Name it **bastions-stand**
4. Make sure **Public** is selected
5. Click **Create repository**
6. On the next page, you'll see a Quick Setup screen
7. Click **"uploading an existing file"** (it's a link in the middle of the page)
8. Drag and drop these 3 files into the upload area:
   - **server.js**
   - **package.json**
   - **public/index.html** ← IMPORTANT: you need to create a folder called `public` first (see note below)
9. Click **Commit changes**

**⚠️ About the public folder:**
GitHub's upload page doesn't let you create folders directly. The easiest way is:
1. After creating the repo, click **Add file** → **Create new file**
2. In the filename box, type: **public/index.html**
   (typing the slash automatically creates the folder)
3. Paste the entire contents of the game-client.html file into the editor
4. Click **Commit changes**
5. Then go back and upload **server.js** and **package.json** to the root of the repo using **Add file** → **Upload files**

### Step 3: Create a Render account

1. Go to **https://render.com**
2. Click **Get Started for Free**
3. Sign up with your GitHub account (this is the easiest way — click "GitHub")
4. Authorize Render to access your GitHub

### Step 4: Deploy the game on Render

1. Once logged into Render, click **New** → **Web Service**
2. Connect your GitHub account if prompted
3. Find and select your **bastions-stand** repository
4. Render will auto-detect it's a Node.js app. Check these settings:
   - **Name**: bastions-stand (or whatever you like)
   - **Region**: pick the one closest to you and your friends
   - **Branch**: main
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
   - **Instance Type**: **Free**
5. Click **Deploy Web Service**
6. Wait 1-2 minutes for it to build and deploy
7. You'll see a green **"Live"** badge and a URL like:
   **https://bastions-stand.onrender.com**

### Step 5: Play with your friends!

1. Open that URL in your browser
2. Click **CREATE ROOM**
3. You'll get a 5-letter room code (like "HX7KP")
4. Send that code to your friends (WhatsApp, text, whatever)
5. Your friends open the same URL and click **JOIN**, then type in the code
6. Everyone picks a trait
7. Anyone clicks **START GAME**
8. Have fun!

**Note:** The first time someone opens the URL after nobody has used it for 15 minutes, it takes about 30-60 seconds to wake up. This is normal on the free plan. Once one person loads it, it stays awake for everyone.

---

## HOW TO PLAY

### The Basics
- The map has a winding path split into 4 zones
- Each player controls one zone and can only build towers in their zone
- Enemies walk along the path through all zones
- If an enemy reaches the end, your team loses a life (you share 20 lives)
- Survive all 20 waves to win!

### Building Towers
1. Click a tower icon in your panel at the bottom of the screen
2. Click an empty circular spot in YOUR zone on the map
3. The tower costs gold (shown on the icon)

### Upgrading Towers
1. Click on a tower you own
2. A panel pops up showing 2 upgrade paths — pick one
3. You can also sell towers for 60% of their cost

### Earning Gold
- You earn gold when enemies die in YOUR zone
- The further enemies get before dying, the more gold goes to later zones
- You can send gold to teammates using the **Send Gold** button

### Sending Waves
- Click **SEND WAVE** when your team is ready
- Enemies get tougher each wave
- A boss appears every 5th wave
- After wave 10, some enemies spawn from the middle of the path too

---

## PLAYER TRAITS (pick one each)

| Trait | Bonus | Best Tower |
|-------|-------|------------|
| ⚡ Swift Commander | 30% faster fire rate | 🏹 Arrow Tower |
| 💥 Blast Expert | 35% bigger explosions | 💣 Cannon Tower |
| 🔮 Arcane Mastery | 30% more range | 🔮 Magic Tower |
| 🎯 Dead Eye | 20% chance for double damage | 🎯 Sniper Tower |

Each trait benefits ALL your towers a little, but it's strongest on the matching tower type.

---

## TOWERS & UPGRADES

### 🏹 Arrow Tower (50g)
Fast attacks, low damage. Great for chipping away at groups.
- **⚡🏹 Rapid Fire** (75g) — Shoots much faster
- **🏹🏹 Multishot** (75g) — Hits 3 enemies at once

### 💣 Cannon Tower (100g)
Slow but hits an area. Good against groups.
- **🎆 Mortar** (100g) — Bigger explosion radius
- **⚔💣 Siege Cannon** (120g) — Massive single hits

### 🔮 Magic Tower (75g)
Slows enemies on hit. Great support tower.
- **⚡ Lightning** (100g) — Chains to 3 nearby enemies
- **❄ Frost** (100g) — Heavy slow + chance to freeze

### 🎯 Sniper Tower (125g)
Long range, high damage, slow fire. Picks off tough enemies.
- **🎯⬆ Marksman** (125g) — Even more damage and range
- **🗡 Assassin** (130g) — 15% chance to instantly kill enemies below half health

---

## ENEMIES

| Enemy | Speed | Toughness | Appears |
|-------|-------|-----------|---------|
| 🧟 Zombie | Normal | Normal | Wave 1+ |
| 💀 Skeleton | Fast | Low | Wave 2+ |
| 👹 Ogre | Slow | Very High | Wave 4+ |
| 🦇 Wyvern | Fast | Medium | Wave 6+ |
| 👑 Warlord (Boss) | Very Slow | Extreme | Every 5th wave |

---

## TIPS

- **Early game**: Arrow towers are cheap and effective against the first few waves
- **Zone 1 players** see enemies first — focus on slowing them down (Magic towers)
- **Zone 4 players** are the last line of defense — Sniper towers can pick off survivors
- **Cannons** shine against big groups in the mid-game
- **Send gold** to teammates who are struggling — you're a team!
- **Upgrade > new towers** in most cases — one upgraded tower beats two basic ones
- **Mix tower types** — don't put all your eggs in one basket
